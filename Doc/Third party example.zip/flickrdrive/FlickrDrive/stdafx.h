// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once
#pragma warning(disable: 4091)
#pragma warning(disable: 4838)

#include "ShFrwk.h"

#include "resource.h"

#include "FileSystem.h"

extern CFlickrModule _ShellModule;


