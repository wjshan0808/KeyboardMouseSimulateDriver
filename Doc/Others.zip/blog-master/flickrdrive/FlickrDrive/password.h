#ifndef __PASSWORD_H__ 
#define __PASSWORD_H__

#define FLICKR_API_KEY             _T("33333333333333333333333333333333")
#define FLICKR_SECRET_KEY          _T("0123456789012345")

#endif