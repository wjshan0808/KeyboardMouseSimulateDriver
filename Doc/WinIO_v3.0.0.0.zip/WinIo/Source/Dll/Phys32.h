#ifndef PHYS32_H
#define PHYS32_H

extern DWORD (WINAPI *VxDCall)(DWORD Service, DWORD EAX_Reg, DWORD ECX_Reg);

#endif